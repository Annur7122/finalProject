# Configuration for new project JavaEE (without Tomcat)

IntelijIdea + library configuration for JavaEE project

## Description

Added to jakarta servlet, javax.servlet, mysqlconnector libraries.
Customized project structure for HttpServlet projects

## Getting Started

### Dependencies

* There is no dependencies, install IntelijIdea for your laptop

## Authors

Alisher Manatbek
[@aleshnasx](https://t.me/aleshnasx)
